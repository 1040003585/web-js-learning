# commands

This extension shows how to use the `commands` manifest key to register keyboard shortcuts for your extension.

It registers a shortcut (Ctrl+Shift+U) to send a command to the extension (Command+Shift+U on a Mac).
When the user enters the shortcut, the extension opens a new browser tab and loads https://developer.mozilla.org into it.
