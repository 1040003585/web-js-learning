## What it does

This extension searches across multiple tabs and calls find on each of those pages. If it finds the string, the string is highlighted.

## What it shows

How to use the tabs, find and sendMessage APIs.

Icon is from: http://bit.ly/2xyHiZv
