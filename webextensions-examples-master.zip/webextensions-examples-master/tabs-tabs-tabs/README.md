# tabs, tabs, tabs

## What it does

This extension includes a browser action with a popup specified as "tabs.html".

The popup lets the user perform various simple operations using the tabs API.

# What it shows

Demonstration of various tabs API functions.
