# Themes: weta_fade

## What it does

Employs a PNG image as the headerURL image in a theme.

## What it shows

How to create a single image theme, using a faded edge and background color to ensure
the image works well on a range of screen sizes.
